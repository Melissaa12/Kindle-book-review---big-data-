pip install boto3
pip install pyyaml
# echo enter your aws_access_key_id
# read access_key_id
# echo enter your aws_secret_access_key
# read aws_secret_access_key
# echo enter your aws_session_token
# read aws_session_token
# echo please enter your aws keyname
# read key_name
# echo enter your path to your key
# read key_path
# echo credentials
echo 'how many slave nodes do you want for the data analytics'
read numberOfSlaves
access_key_id=ASIA2BUDARD27TXY6RNM
aws_secret_access_key=WFsw2TPb2OFniksRZvBTAvmFkHcg3QxCTZecWQtl
aws_session_token=FwoGZXIvYXdzEAwaDHS1kXM48ulDguYHySLKAU3YkMzb3GFS9E9mmqTXR23+Kz9BB68HSTTT8U87WqAMijKWJ5RpG8MCh5DOSjfiYtDBiIst2WLewQplq+91RyMSybb0VakIsVY/j7Fa3vwwjePjzvYGZNQQOTlduxxgexjnW545yRRaCHCmR5NwBM0y2tCa7CbE8z4ZElPhZUrhaWSROOwFYamQJukTmK7StQ5fH4gL8mAOUGhlVK7EzTjtYErTuyNQVszA3MfsFjFmAzt4qmG8gB6SkQUybY1k223g5E19BNDqpmUont+W/gUyLUjRkVH1xpk0S97Omfdw7fYHUGnhebLsxIlpEnlLEWLYUhcshtSR9FQFgZUQHw==
key_name=dbproject
key_path=/Users/ryan/Desktop/DBProject/SQL/dbproject.pem
echo "$access_key_id"
echo "$aws_secret_access_key"
echo "$aws_session_token"
echo "$key_name"
echo "$key_path"
python createEC2.py $access_key_id $aws_secret_access_key $aws_session_token $key_name $numberOfSlaves
pip install paramiko
python sshEC2.py $access_key_id $aws_secret_access_key $aws_session_token $key_path $key_name $numberOfSlaves