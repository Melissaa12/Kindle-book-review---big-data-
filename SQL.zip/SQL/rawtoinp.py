import os
import sys
folder_path = '/Users/ryan/Desktop/BAUM-2_S251_S286'
for filename in os.listdir(folder_path):
	print(filename)