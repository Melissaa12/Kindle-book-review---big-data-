import json
template_file_location = "./testsave3.json"
#cloud_formation_client = boto3.client('cloudformation',aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key,aws_session_token=aws_session_token,region_name="us-east-1")
# # read entire file as yaml
with open(template_file_location, 'r') as content_file:
    content = json.load(content_file)
tempfile = open("./testsavenew.json" , 'w')
tempVal  ={
            "Type": "AWS::EC2::Instance",
            "Properties": {
                "ImageId": "ami-0f82752aa17ff8f5d",
                "InstanceType": "t2.medium",
                "SecurityGroups": [
                    {
                        "Ref": "DataSecurity"
                    }
                ],
                "KeyName": {
                    "Ref": "KeyName"
                }
            }}
#content = json.dumps(content)
n = 4
for i in range(0, n):
	content["Resources"]["Slave"+str(n+i)] = tempVal

json.dump(content, tempfile)
tempfile.close() 
