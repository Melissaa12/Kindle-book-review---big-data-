pip install boto3
pip install pyyaml
# echo enter your aws_access_key_id
# read access_key_id
# echo enter your aws_secret_access_key
# read aws_secret_access_key
# echo enter your aws_session_token
# read aws_session_token
# echo please enter your aws keyname
# read key_name
# echo enter your path to your key
# read key_path
# echo credentials
echo 'how many slave nodes do you want for the data analytics'
read numberOfSlaves
access_key_id=ASIA2BUDARD2SE2OTIVO
aws_secret_access_key=s/vM5GfBg5ADJSmK2hfdqVnSl43oDG5r7I76+8gG
aws_session_token=FwoGZXIvYXdzEEEaDBsLudY0lj5ct4MPQCLKATugiT9wRrF+mOKTgLgRL48SrOK0DxijMmMuD9WIt91035RzXUqJAM+tYBtyGSrZ92D8GlFhHkiiHVbAguH5mvXSVcf8y/0F2OtoDTt1dBGbYTQkhubuHE//2xCCLwXTHJybU6I95FZ3vfvSJoJjqf7sqJKZx2VyLii4vvSTDj7Z5DGB7nZjwsHEuRJCBGcrj8+cu7wp+nDxYDjuI4freRKWlTMYGUVmkGzqnzEmvXijZv2aGHQSPCFxCBlNY8OrbS6qUuqTzaR9HxEo3LGi/gUyLSXHKLHusfsVyIVnEBBus7tqMCdk0emrle+fuhyECOxW6Gmu0HNWPNyd+Y0wMQ==
key_name=dbproject
key_path=/Users/ryan/Desktop/DBProject/SQLWITHPROFINS/dbproject.pem
echo "$access_key_id"
echo "$aws_secret_access_key"
echo "$aws_session_token"
echo "$key_name"
echo "$key_path"
python createEC2.py $access_key_id $aws_secret_access_key $aws_session_token $key_name $numberOfSlaves
pip install paramiko
python sshEC2.py $access_key_id $aws_secret_access_key $aws_session_token $key_path $key_name $numberOfSlaves