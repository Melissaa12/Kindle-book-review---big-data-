sudo su hadoop 
export LC_ALL=C
sudo apt-get update
sudo apt-get install -y openjdk-8-jdk
javac -version